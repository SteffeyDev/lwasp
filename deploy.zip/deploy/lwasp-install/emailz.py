# Copyright (C) 2015 Peter Steffey

from utility import sendScoringReport
from utility import notify

sendScoringReport()
notify('Sent!', 'Your Scoring Report has been sent to the administrator')
